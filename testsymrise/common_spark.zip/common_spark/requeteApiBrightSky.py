import requests
import json
from common_spark.mongodb_connection import get_database
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from datetime import datetime
from dateutil.relativedelta import relativedelta



def get_data_from_brightsky(latitude, longitude):
    

    one_yr_ago = datetime.now() - relativedelta(days=700)
    query = f"https://api.brightsky.dev/weather?date={one_yr_ago}&last_date={datetime.now()}&lat={latitude}&lon={longitude}"
    # print('query : ', query)
    r = requests.get(query)

    response = r.text
    json_object = json.loads(response)
    # print(json_object["weather"])
    # print(r.text)

    return json_object["weather"]

# get_data_from_brightsky(52.52,13.4)

#STUDIED_CITIES = [{"city": "Berlin", "latitude":52.52, "longitude":13.4},
#                      {"city": "Koln", "latitude":50.9375, "longitude":6.9603},{"city": "Munchen", "latitude":48.1351, "longitude":11.5820}]

#for i in STUDIED_CITIES:
#    print(i["city"])



